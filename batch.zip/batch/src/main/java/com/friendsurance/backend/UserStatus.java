package com.friendsurance.backend;

public class UserStatus 
{

    private Integer id;
    private String email;
    private String mailType;
    private String timeStamp;
    private String status;

    public String getEmail() {
        return email;
    }


    public void setEmail(String email) {
        this.email = email;
    }


    public String getMailType() {
        return mailType;
    }


    public void setMailType(String mailType) {
        this.mailType = mailType;
    }

    public String getTimeStamp() {
        return timeStamp;
    }


    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getStatus() {
        return status;
    }


    public void setStatus(String status) {
        this.status = status;
    }
}
