package com.friendsurance.processing;

import java.util.List;

import com.friendsurance.backend.User;
import com.friendsurance.backend.UserStatus;
import com.friendsurance.mail.EmailRecipient;
import com.friendsurance.mail.EmailService;
import com.friendsurance.mail.EmailService.MailType;

public class ItemProcessingUser extends ItemProcessing<User, UserStatus>
{

	  public  ItemProcessingUser(ItemReader<User> reader, ItemWriter<UserStatus> writer, EmailService emailService) {
	        super(reader, writer, emailService);
	    }
	

	/*As part of our efforts to have more and more engaged users, we decided to start sending emails every night at 3 AM. 
	 * These emails relate to the current situation of each user. For example:

		If a user has registered more than 7 days ago and has no friends in our platform right now, we would like to send an email encouraging them to be more active.
		 The mail could contain something like "Hey, do you remember us? Give us a try and be social with your insurances!"
		Another user which registered more than 7 days ago and has friends in our platform but no contract, does not need to be reactivated.
		 But it could be interesting for them if we offer some price attractive tariff so they could save money together with their friends.
	*/	
	protected boolean sendMailForUser(UserStatus item) 
	{

		boolean finalResult = false;
        try {
            	finalResult = emailService.sendMail(item.getEmail(), EmailService.MailType.valueOf(item.getMailType()));
                if (finalResult) 
                {
                	item.setStatus("SUCCESS");
                }
                else 
                {
                	item.setStatus("FAILED");

                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
		return finalResult;

    }
	
	@Override
	protected UserStatus process(User item) throws Exception {
		// TODO Auto-generated method stub
		int friend  = item.getFriendsNumber();
		boolean hasContract = item.hasContract();
		int invitation = item.getSentInvitationsNumber();
		final String UserEmail  = item.getEmail();

		if(!hasContract && friend > 3 && invitation > 1 )
		{
			//MAIL_TYPE_1
			 UserStatus status = new UserStatus() {{
                setEmail(UserEmail);
                setMailType(EmailService.MailType.MAIL_TYPE_1.name());
            }};
            return status;
		}
		else if(!hasContract && ((friend == 0 && invitation == 0) || (friend < 3 && invitation > 1)))
		{
			//MAIL_TYPE_2
			 UserStatus status = new UserStatus() {{
                 setEmail(UserEmail);
                 setMailType(EmailService.MailType.MAIL_TYPE_2.name());
             }};
             
             return status;
		}
		else if((!hasContract && (friend > 1 && invitation == 0) || (friend < 3 && invitation > 6)) ||
				(hasContract && (friend == 0 && invitation == 0) || (friend == 0 && invitation > 3)) )
		{
			//MAIL_TYPE_3
			 UserStatus status = new UserStatus() {{
                 setEmail(UserEmail);
                 setMailType(EmailService.MailType.MAIL_TYPE_3.name());
             }};
             return status;
		}
		else if(hasContract && friend > 1 && invitation < 0)
		{
			//MAIL_TYPE_4
			 UserStatus status = new UserStatus() {{
                 setEmail(UserEmail);
                 setMailType(EmailService.MailType.MAIL_TYPE_4.name());
             }};
             return status;
		}
		return null;
	}
	
}
