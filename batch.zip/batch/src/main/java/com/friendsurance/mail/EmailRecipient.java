package com.friendsurance.mail;

/**
 * Provides information about email recipient
 */
public interface EmailRecipient {

    String getEmail();

}
